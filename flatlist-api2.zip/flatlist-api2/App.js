import {
  Text,
  SafeAreaView,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Image,
  View,
} from 'react-native';
import React, { useEffect, useState } from 'react';

export default function App() {
  const [kullanicilar, setKullanicilar] = useState([]);

  useEffect(
    () =>
      fetch('https://dummyjson.com/users').then((resp) =>
        resp.json().then((json) => setKullanicilar(json.users))
      ),
    []
  );

  return (
    <SafeAreaView style={styles.container}>
      <FlatList
        data={kullanicilar}
        style={{ width: '100%', alignItems: 'center' }}
        //horizontal
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => <Box kullanici={item} />}
      />
    </SafeAreaView>
  );
}

const Box = ({ kullanici }) => {
  return (
    <TouchableOpacity
      style={{
        height: 75,
        width: '90%',
        borderRadius: 25,
        backgroundColor: (kullanici.id%2==0?'#898121':'#E5C287'),
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: 10,
        margin: 10,
        flexDirection: 'row',
      }}>
      <Image
        source={{ uri: kullanici.image }}
        style={{ height: 70, width: 70,borderWidth:1,borderColor:'white',borderRadius:35}}
      />
      <View style={{ alignItems: 'flex-end' }}>
        <Text style={{ fontSize: 20, fontWeight: 'bold', color: 'white' }}>
          {kullanici.firstName} {kullanici.lastName}
        </Text>
        <Text>{kullanici.email}</Text>
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
});

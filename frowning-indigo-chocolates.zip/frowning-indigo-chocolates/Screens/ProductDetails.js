/* eslint-disable react-native/no-inline-styles */
import {View, Text, Image, StyleSheet, TouchableOpacity} from 'react-native';
import React, {useEffect, useState} from 'react';

const ProductDetails = ({route, navigation}) => {
  const {itemTitle} = route.params;
  const [value, setValue] = useState([]);

  useEffect(() => {
    fetch('https://dummyjson.com/products/' + itemTitle)
      .then(res => res.json())
      .then(json => setValue(json));
  }, [itemTitle]);

  let img = value.images;

  return (
    <View style={styles.container}>
      <Text>{value.title}</Text>
      <View
        style={{
          flexDirection: 'row',
          height: '60%',
          width: '80%',
          padding: 10,
          margin: 10,
          justifyContent: 'center',
          alignItems: 'center',
        }}>
        <Image
          source={{uri: value.thumbnail}}
          style={{
            height: '90%',
            width: '90%',
            borderWidth: 1,
            borderColor: 'orange',
            borderRadius:10
          }}
        />
      </View>
      <Text>{value.description}</Text>
      <Text>${value.price}</Text>
      <View
        style={{
          flexDirection: 'row',
          justifyContent: 'space-around',
          alignItems: 'stretch',
        }}>
        <TouchableOpacity
          style={styles.button}
          onPress={() => navigation.goBack()}>
          <Text>Back</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button}>
          <Text>Add Cart</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default ProductDetails;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'space-around',
    alignItems: 'center',
    padding: 5,
    margin: 5,
  },
  button: {
    borderWidth: 3,
    borderRadius: 20,
    height: 50,
    width: 150,
    margin: 5,
    padding: 5,
    alignItems: 'center',
    justifyContent: 'center',
    borderColor: 'orange',
  },
});

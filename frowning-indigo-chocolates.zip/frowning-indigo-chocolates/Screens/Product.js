/* eslint-disable react-native/no-inline-styles */
import {TouchableOpacity, Text, Image, SafeAreaView} from 'react-native';
import React from 'react';

const Product = ({p, navigation}) => {
  return (
    <SafeAreaView>
      <TouchableOpacity
        key={p.id}
        style={{
          height: 200,
          width: 100,
          borderWidth: 2,
          borderColor: 'orange',
          borderRadius: 5,
          padding: 2,
          margin: 2,
          alignItems: 'center',
          justifyContent: 'space-around',
        }}
        onPress={() => navigation.navigate('ProductDetail', {itemTitle: p.id})}>
        <Image source={{uri: p.images[0]}} style={{height: 75, width: 75}} />
        <Text key={p.id}>{p.title}</Text>
        <Text key={(p.id + 1) * 100}>${p.price}</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
};

export default Product;

import {SafeAreaView, FlatList, ActivityIndicator} from 'react-native';
import React, {useState, useEffect} from 'react';

import Product from './Product';

const ProductList = ({route,navigation}) => {
  const [product, setProduct] = useState([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    fetch('https://dummyjson.com/products')
      .then(res => res.json())
      .then(json => setProduct(json.products))
      .finally(e => setLoading(false));
  }, []);

  return (
    <SafeAreaView style={{alignItems:'center',padding:10,margin:10}}>
      {loading ? (
        <ActivityIndicator size={'large'} color={'orange'} />
      ) : (
        <FlatList
          data={product}
          numColumns={3}
          keyExtractor={item => item.id}
          renderItem={({item}) => <Product p={item} navigation={navigation} />}
        />
      )}
    </SafeAreaView>
  );
};

export default ProductList;

import React from 'react';
import Routes from './navigation/route';

const App = () => {
  return <Routes />;
};

export default App;